﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp16___Assignment_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Baanking b = new Baanking();
            b.Netbalance = Convert.ToInt32(textBox1.Text);
            if(b.Netbalance >= 100000)
            {
                b.overbalance(b.Netbalance);
            }
            else if(b.Netbalance <= 5000)
            {
                b.underbalance();
            }
            else
            {
                MessageBox.Show("Your balance is maintained...");
            }
        }
    }
}
