﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp16___Assignment_6
{
    public class Baanking
    {
        int netBalance;

        public int Netbalance
        {
            set { netBalance = value; }
            get { return netBalance; }
        }
        public void overbalance(int amount)
        {
            double tax = amount * 0.18;
            MessageBox.Show("Your tax amount is: " +tax);

        }
        public void underbalance()
        {
            MessageBox.Show("Please maintain your minimum balance.");
        }
    }
}
