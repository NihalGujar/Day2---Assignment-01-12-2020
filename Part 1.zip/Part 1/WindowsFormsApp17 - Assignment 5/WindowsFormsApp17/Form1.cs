﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int no1, no2;
        string op;
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + (sender as Button).Text;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            no1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = (sender as Button).Text;


        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(System.Math.Sin((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(textBox1.Text))));
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(System.Math.Cos((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(textBox1.Text))));
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(System.Math.Tan((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(textBox1.Text))));
        }

        private void button16_Click(object sender, EventArgs e) //Cosec()
        {
            if (radioButton2.Checked == true)
            {
                textBox1.Text = Convert.ToString(System.Math.Asin(Convert.ToDouble(textBox1.Text)));
            }
            else
            {
                textBox1.Text = Convert.ToString(System.Math.Asin(Convert.ToDouble(System.Math.PI) / 180) * Convert.ToDouble(textBox1.Text));
            }
        }

        private void button15_Click(object sender, EventArgs e)//SEC()
        {
            if (radioButton2.Checked == true)
            {
                textBox1.Text = Convert.ToString(System.Math.Acos(Convert.ToDouble(textBox1.Text)));
            }
            else
            {
                textBox1.Text = Convert.ToString(System.Math.Acos(Convert.ToDouble(System.Math.PI) / 180) * Convert.ToDouble(textBox1.Text));
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                textBox1.Text = Convert.ToString(System.Math.Atan(Convert.ToDouble(textBox1.Text)));
            }
            else
            {
                textBox1.Text = Convert.ToString(System.Math.Atan(Convert.ToDouble(System.Math.PI) / 180) * Convert.ToDouble(textBox1.Text));
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text = "3.14159265359";
        }
        double result;
        private void button19_Click(object sender, EventArgs e)
        {
            result = (System.Math.Sqrt(Convert.ToDouble(textBox1.Text)));
            textBox1.Text = Convert.ToString(result);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            result = Convert.ToDouble(textBox1.Text)* Convert.ToDouble(textBox1.Text);
            textBox1.Text = Convert.ToString(result);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox1.Text = "";
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
            button20.Enabled = true;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            no2 = Convert.ToInt32(textBox1.Text);
            switch (op)
            {
                case "+":
                    textBox1.Text = (no1 + no2).ToString();
                    break;
                case "-":
                    textBox1.Text = (no1 - no2).ToString();
                    break;
                case "*":
                    textBox1.Text = (no1 * no2).ToString();
                    break;
                case "/":
                    textBox1.Text = (no1 / no2).ToString();
                    break;
                default:
                    break;

            }
        }


    }
}
