﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication25
{
    public partial class WebUserControl1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            float val = float.Parse(TextBox1.Text);
            if (DropDownList1.SelectedValue == "INR" && DropDownList2.SelectedValue == "USD")
            {
                float result = val / 70;
                TextBox2.Text = result.ToString();

            }
            else if (DropDownList1.SelectedValue == "USD" && DropDownList2.SelectedValue == "INR")
            {
                double result = val * 70;
                TextBox2.Text = Convert.ToDouble(result).ToString();

            }

            else if (DropDownList1.SelectedValue == "INR" && DropDownList2.SelectedValue == "EURO")
            {
                float result = val / 88;
                TextBox2.Text = result.ToString();

            }
            else if (DropDownList1.SelectedValue == "EURO" && DropDownList2.SelectedValue == "INR")
            {
                double result = val * 88;
                TextBox2.Text = Convert.ToDouble(result).ToString();

            }
            else if (DropDownList1.SelectedValue == "INR" && DropDownList2.SelectedValue == "EURO")
            {
                double result = val / 88;
                TextBox2.Text = Convert.ToDouble(result).ToString();
            }

            else if (DropDownList1.SelectedValue == "USD" && DropDownList2.SelectedValue == "EURO")
            {
                double result = val / 1.21;
                TextBox2.Text = Convert.ToDouble(result).ToString();

            }
            else if (DropDownList1.SelectedValue == "EURO" && DropDownList2.SelectedValue == "USD")
            {
                double result = val * 1.21;
                TextBox2.Text = Convert.ToDouble(result).ToString();
            }
            else
            {
                Console.WriteLine("Please Select Valid Conversion ");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            DropDownList1.ClearSelection();
            DropDownList2.ClearSelection();
            TextBox1.Text = "";
            TextBox2.Text = "";
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}